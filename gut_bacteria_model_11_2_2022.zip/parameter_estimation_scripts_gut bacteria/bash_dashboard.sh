
#for dir in *; do [ -d "$dir" ] && cp mc17_samples.f90  "$dir" ; done

p="/data/Himanshu/Work/gut_bacteria/work_gut_bacteria/march_2021/17_June_2021/analysis"


function recursive_for_loop { 
    ls -1| until ! read f; do
        if [ -d $f  -a ! -h $f ];  
        then  
            cd -- "$f";  
            echo "Doing something in folder `pwd`/$f"; 
              rm *csv
              rm -r analysis/ 
  #             gfortran constants.f90 mc17_new.f90 
   #            nohup ./a.out &

              cp $p/mc17_samples.f90 .    
              cp $p/p_corr.f90 .
              cp $p/python_subplot.py .
              cp $p/pre_data.sh .
             # cp mc17_samples.f90 -- "$f";

              bash pre_data.sh

             #result=${PWD##*/}          # to assign to a variable
            # printf 'result'

              
             # printf '%s\n' "${PWD##*/}"
              #printf  "${PWD##*/}"

             
             # rm -r analysis/
            # use recursion to navigate the entire tree
            recursive_for_loop;
            cd ..; 
        fi;  
    done; 
};
recursive_for_loop
