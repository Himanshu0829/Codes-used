# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.

"""



import matplotlib.pyplot as plt
#import csv
import glob
import numpy as np
import pandas as pd
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator)
from io import StringIO
import os
path='/data/Himanshu/Work/gut_bacteria/work_gut_bacteria/march_2021/17_June_2021/analysis/obese/co_ran'
f=sorted(glob.glob(os.path.join(path,'*.dat')))
#filenames = sorted(glob.glob('*dat'))
print(f)
y=[]

for hj in f:
    x=hj.split("/")
    #print(x[-1])
    y.append(x[-1])
    #y.append(z)
    
print(type(y[0]))

#print(f)

#row,col=4,2

fig,ax=plt.subplots(nrows=2,ncols=4,sharex=True, sharey=True, figsize=(6,4))

l=len(y)
print (l)
#print(os.getcwd())
data1=pd.read_fwf('/data/Himanshu/Work/gut_bacteria/work_gut_bacteria/march_2021/8_June_2021/int_matrix_co_vs_ran/sy_0.2.dat',sep = '[ , |\t]',usecols=range(0,3))
print(data1)
#print(os.path.isfile('asy_0.0.dat'))
for n in range (len(y)):
  
  
  print(n)  
  
  #Data = np.genfromtxt(f[n],delimiter=' ',usecols=(0,1))
  Data = pd.read_fwf(f[n],sep = '[ , |\t]',usecols = range(0,2),header=None,index=False,figsize=(6,4))
  
 #  t=len(x)
  y1 = Data.iloc[:,0]
  y2 = Data.iloc[:,1]
  #print(y[n])
  #print(y1)
  
  #print(len(y1))

  ax = plt.subplot(2,4,n+1)
  
  ax.scatter(y1,y2,s=2,c="red")
  #ax1 = ax.twinx()
 
 # ax1.plot(x,y2,c="red")
  
  ax.set_title(y[n][:-4],fontsize=10,pad=0.5)
  ax.set_xlabel('Co-occurrence Input',labelpad=0.4,fontsize=7)
  ax.set_ylabel('Random Input',labelpad=0.4,fontsize=7)
  ax.xaxis.set_tick_params(labelsize=5,pad=0.4)
  ax.yaxis.set_tick_params(labelsize=5,pad=0.4)
#fig.subplots_adjust(left=0.15, bottom=0.05, right=0.95, top=0.95, wspace=0.2, hspace=0.1)
#fig.savefig(os.path.join(path,'test.png',dpi=300))
  
#plt.suptitle("Abundance RMSD(Asymetric_co)",fontsize=15)
  fig.subplots_adjust(left=0.1, bottom=0.1, right=0.95, top=0.7, wspace=0.5, hspace=0.4)
#plt.savefig('/data/Himanshu/Work/gut_bacteria/work_gut_bacteria/march_2021/8_June_2021/int_matrix_co_vs_ran/test_test.png',dpi=200)  
fig.savefig('test2.png',dpi=300)  
plt.show()
#plt.imshow(img)
#plt.gcf().set_dpi(300)
#plt.show(dpi=600)
